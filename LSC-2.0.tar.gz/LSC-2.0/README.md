LSC
===

LSC is a long read error correction tool developed by Kin Fai Au and Pegah T Afshar. It offers fast correction with high sensitivity and good accuracy.
